<!-- remove 'no-archive' header -->
<?cs call:checkbox("i") ?>
