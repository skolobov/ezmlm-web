<!-- only subscribers may post -->
<?cs call:checkbox("u") ?>
