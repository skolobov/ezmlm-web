#define EZMLM_WEB_CGI "/usr/bin/ezmlm-web.cgi"
