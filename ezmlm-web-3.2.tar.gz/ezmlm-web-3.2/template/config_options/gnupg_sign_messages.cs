<?cs if:Data.List.Features.Crypto ?>
<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- Gnupg: sign outgoing messages -->
<?cs call:checkbox("gnupg_sign_messages") ?>
<?cs /if ?>

