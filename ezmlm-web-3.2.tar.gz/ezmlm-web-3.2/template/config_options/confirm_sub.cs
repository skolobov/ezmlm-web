<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- do not require confirmation for subscription -->
<?cs call:checkbox("h") ?>
