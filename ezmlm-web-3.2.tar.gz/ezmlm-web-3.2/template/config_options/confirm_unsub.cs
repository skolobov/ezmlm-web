<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- do not require confirmation for unsubscribe -->
<?cs call:checkbox("j") ?>
