
	<div id="footer">
		<a href="https://systemausfall.org/toolforge/ezmlm-web">ezmlm-web</a> (v3.0) - <?cs var:html_escape(Lang.Misc.FooterText) ?> <a href="http://www.ezmlm.org/" target="_blank">ezmlm</a>
		<br />
	</div>

</body>
</html>
