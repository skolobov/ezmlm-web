<!-- do not require confirmation for unsubscribe -->
<?cs call:checkbox("j") ?>
