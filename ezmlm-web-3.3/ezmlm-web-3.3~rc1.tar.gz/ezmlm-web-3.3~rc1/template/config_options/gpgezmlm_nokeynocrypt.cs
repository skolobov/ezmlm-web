<?cs if:Data.List.Features.GpgEzmlm ?>
<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- Gnupg: send warning without original content if no key is available -->
<?cs call:checkbox("gpgezmlm_nokeynocrypt") ?>
<?cs /if ?>

