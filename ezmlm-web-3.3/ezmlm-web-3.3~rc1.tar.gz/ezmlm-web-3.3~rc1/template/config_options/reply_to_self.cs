<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- Gnupg: sign outgoing messages -->
<?cs call:checkbox("special_replytoself") ?>
