<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- require confirmation from poster -->
<?cs call:checkbox("y") ?>
