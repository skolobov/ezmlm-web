<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- administrators may request subscribers list -->
<?cs call:checkbox("l") ?>
