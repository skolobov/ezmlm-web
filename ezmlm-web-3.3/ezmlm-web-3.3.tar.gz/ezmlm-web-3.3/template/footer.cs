
	<div id="footer">
		<a href="https://systemausfall.org/toolforge/ezmlm-web">ezmlm-web</a>
		(v<?cs var:html_escape(Config.Version.ezmlm_web) ?>)
		- <?cs var:html_escape(Lang.Misc.FooterText) ?>
		<a href="http://www.ezmlm.org/" target="_blank">ezmlm</a>
		<br />
	</div>

</body>
</html>
