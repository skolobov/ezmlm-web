<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- subscription rules -->
<?cs call:selection_list("subscribe") ?>
