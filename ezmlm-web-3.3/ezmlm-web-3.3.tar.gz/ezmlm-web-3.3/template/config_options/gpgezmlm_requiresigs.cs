<?cs if:Data.List.Features.GpgEzmlm ?>
<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- Gnupg: sign outgoing messages -->
<?cs call:checkbox("gpgezmlm_requiresigs") ?>
<?cs /if ?>

