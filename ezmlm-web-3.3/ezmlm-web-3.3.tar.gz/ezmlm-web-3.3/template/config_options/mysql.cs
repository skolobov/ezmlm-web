<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<?cs if:Data.Modules.mySQL ?>
	<!-- mysql database -->
	<?cs call:setting("6") ?><?cs /if ?>
