<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- only moderators may post -->
<?cs call:checkbox("o") ?>
