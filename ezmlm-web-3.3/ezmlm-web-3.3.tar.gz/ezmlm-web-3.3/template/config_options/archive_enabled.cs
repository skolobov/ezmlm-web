<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- enable archiving -->
<?cs call:checkbox("a") ?>
