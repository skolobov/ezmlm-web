<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- use deny list -->
<?cs call:checkbox("k") ?>
