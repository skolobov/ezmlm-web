<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- turn on digest list -->
<?cs call:checkbox("d") ?>
