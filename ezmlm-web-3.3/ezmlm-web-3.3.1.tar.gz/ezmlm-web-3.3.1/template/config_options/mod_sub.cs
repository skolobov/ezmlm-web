<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- moderate subscription -->
<?cs call:checkbox("s") ?>
