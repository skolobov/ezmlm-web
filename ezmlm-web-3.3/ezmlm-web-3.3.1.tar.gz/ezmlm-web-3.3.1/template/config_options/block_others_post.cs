<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- only subscribers may post -->
<?cs call:checkbox("u") ?>
