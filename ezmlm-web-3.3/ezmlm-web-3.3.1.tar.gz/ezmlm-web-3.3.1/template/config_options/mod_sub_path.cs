<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<?cs if:Data.List.Options.s ?>
	<!-- custom path to subscription moderators -->
	<?cs call:setting("8") ?>
<?cs /if ?>
