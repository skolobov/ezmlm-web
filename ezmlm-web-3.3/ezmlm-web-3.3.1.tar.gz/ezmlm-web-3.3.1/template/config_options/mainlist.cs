<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- set main list name -->
<?cs call:setting("0") ?>
