<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<?cs if:Data.List.Options.m ?>
	<!-- messsage moderator path -->
	<?cs call:setting("7") ?>
<?cs /if ?>
