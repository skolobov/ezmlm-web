<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- remove 'no-archive' header -->
<?cs call:checkbox("i") ?>
