<label for="listname"><?cs var:html_escape(Lang.Misc.ListName) ?>:</label>
	<input type="text" name="new_list" id="listname" size="25">
