<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- from address -->
<?cs call:setting("3") ?>
