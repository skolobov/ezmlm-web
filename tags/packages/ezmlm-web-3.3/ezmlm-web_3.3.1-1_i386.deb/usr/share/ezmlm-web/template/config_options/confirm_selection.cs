<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- configure confirmation requirements -->
<?cs call:selection_checkboxes("confirmation") ?>
