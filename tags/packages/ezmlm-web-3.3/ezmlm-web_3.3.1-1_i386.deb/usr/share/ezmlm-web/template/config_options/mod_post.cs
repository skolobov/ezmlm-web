<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- posted messages are moderated -->
<?cs call:checkbox("m") ?>
