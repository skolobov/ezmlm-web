<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- configure archive access -->
<?cs call:selection_list("archive") ?>
