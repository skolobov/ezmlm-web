<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- enable remote administration -->
<?cs call:checkbox("r") ?>
