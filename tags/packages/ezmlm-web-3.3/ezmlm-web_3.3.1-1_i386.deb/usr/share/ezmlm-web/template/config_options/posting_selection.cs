<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- posting rules -->
<?cs call:selection_list("posting") ?>
