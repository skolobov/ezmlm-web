<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- public subsccription and archive -->
<?cs call:checkbox("p") ?>
