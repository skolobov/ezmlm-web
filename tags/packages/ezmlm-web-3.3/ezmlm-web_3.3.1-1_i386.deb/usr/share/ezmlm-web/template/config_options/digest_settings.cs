<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- digest settings -->
<?cs call:setting("4") ?>
