<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- only moderators may access the archive -->
<?cs call:checkbox("b") ?>
