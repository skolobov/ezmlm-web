<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- block unknown users from archive -->
<?cs call:checkbox("g") ?>
