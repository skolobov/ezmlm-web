<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- process mailman-style requests -->
<?cs call:checkbox("q") ?>
