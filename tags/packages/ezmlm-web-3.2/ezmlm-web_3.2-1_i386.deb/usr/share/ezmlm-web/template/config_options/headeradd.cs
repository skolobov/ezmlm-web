<!-- REMOVE --><?cs include:TemplateDir + '/macros.cs' ?>
<!-- headeradd -->
<?cs var:html_escape(Lang.Misc.HeaderAdd) ?>:<br/>
	<ul><li><textarea name="headeradd" rows="5" cols="70"><?cs
	var:html_escape(Data.List.HeaderAdd) ?></textarea></li></ul>
