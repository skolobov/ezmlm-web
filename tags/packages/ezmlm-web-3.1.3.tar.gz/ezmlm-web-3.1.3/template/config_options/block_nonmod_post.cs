<!-- only moderators may post -->
<?cs call:checkbox("o") ?>
