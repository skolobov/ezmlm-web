<!-- headerremove -->
<?cs var:html_escape(Lang.Misc.HeaderRemove) ?>:<br/>
	<ul><li><textarea name="headerremove" rows="5" cols="70"><?cs
	var:html_escape(Data.List.HeaderRemove) ?></textarea></li></ul>
