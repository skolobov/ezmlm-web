<!-- administrators may request subscribers list -->
<?cs call:checkbox("l") ?>
