<!-- require confirmation from poster -->
<?cs call:checkbox("y") ?>
