<!-- moderate subscription -->
<?cs call:checkbox("s") ?>
