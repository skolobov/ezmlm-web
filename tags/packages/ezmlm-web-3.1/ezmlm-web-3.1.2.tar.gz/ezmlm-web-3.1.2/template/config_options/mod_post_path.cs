<!-- messsage moderator path -->
<?cs call:setting("7") ?>
