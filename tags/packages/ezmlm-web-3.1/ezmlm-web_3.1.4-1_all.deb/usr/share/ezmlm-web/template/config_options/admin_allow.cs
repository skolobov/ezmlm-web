<!-- enable remote administration -->
<?cs call:checkbox("r") ?>

