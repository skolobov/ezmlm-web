<!-- set main list name -->
<?cs call:setting("0") ?>
