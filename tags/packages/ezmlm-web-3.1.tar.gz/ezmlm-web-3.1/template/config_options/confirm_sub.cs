<!-- do not require confirmation for subscription -->
<?cs call:checkbox("h") ?>
